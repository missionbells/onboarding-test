"use client"
import { OnboardingFlow } from "@/components/onboarding-flow"

export default function Home() {
  return <OnboardingFlow />
}
